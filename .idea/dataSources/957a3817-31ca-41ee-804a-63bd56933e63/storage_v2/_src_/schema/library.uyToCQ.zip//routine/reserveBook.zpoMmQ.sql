create
    definer = root@localhost procedure reserveBook(IN studentId int, IN bookId int, IN takeDate date)
label: BEGIN
    START TRANSACTION;
    -- 判断是否处于冻结状态
    IF (SELECT status FROM student, user WHERE student.sid = studentId AND student.sid = user.uid AND user.role = 0) = 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '您的账号已被冻结，无法操作！';
        -- 回滚事务
        ROLLBACK;
        -- 结束存储过程
        LEAVE label;
    END IF;
    -- 插入预约记录
    INSERT INTO reserve(sid, bid, reserve_date, take_date) VALUES (studentId, bookId, CURDATE(), takeDate);
    -- 更新书籍状态
    UPDATE book SET status = 1 WHERE bid = bookId;
    COMMIT;
END;

