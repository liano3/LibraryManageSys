create
    definer = root@localhost function hotBook() returns int reads sql data
BEGIN
    DECLARE hotBookId INT;
    SELECT bid INTO hotBookId FROM borrow WHERE MONTH(borrow_date) = MONTH(CURDATE()) GROUP BY bid ORDER BY COUNT(*) DESC LIMIT 1;
    RETURN hotBookId;
END;

