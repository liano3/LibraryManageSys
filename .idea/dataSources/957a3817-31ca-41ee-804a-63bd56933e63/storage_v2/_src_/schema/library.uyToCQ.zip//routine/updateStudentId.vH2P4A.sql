create
    definer = root@localhost procedure updateStudentId(IN oldId int, IN newId int)
BEGIN
    START TRANSACTION;
    SET FOREIGN_KEY_CHECKS = 0;
    UPDATE student SET sid = newId WHERE sid = oldId;
    UPDATE borrow SET sid = newId WHERE sid = oldId;
    UPDATE reserve SET sid = newId WHERE sid = oldId;
    UPDATE user SET uid = newId WHERE uid = oldId;
    SET FOREIGN_KEY_CHECKS = 1;
    COMMIT;
END;

