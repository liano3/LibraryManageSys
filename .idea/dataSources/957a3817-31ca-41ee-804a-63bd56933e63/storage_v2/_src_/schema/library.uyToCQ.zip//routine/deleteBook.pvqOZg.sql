create
    definer = root@localhost procedure deleteBook(IN bookId int)
BEGIN
    START TRANSACTION;
    SET FOREIGN_KEY_CHECKS = 0;
    DELETE FROM book WHERE bid = bookId;
    DELETE FROM reserve WHERE bid = bookId;
    DELETE FROM borrow WHERE bid = bookId;
    SET FOREIGN_KEY_CHECKS = 1;
    COMMIT;
END;

