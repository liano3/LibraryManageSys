create definer = root@localhost trigger returnBook
    after update
    on borrow
    for each row
BEGIN
    -- 区分续借和还书
    if NEW.return_date is not null THEN
        UPDATE book SET status = 0 WHERE bid = NEW.bid;
    END IF;
END;

