create
    definer = root@localhost procedure unkillUser(IN studentId int, IN s int)
label: BEGIN
    START TRANSACTION;
    -- 解冻用户
    UPDATE user SET status = s WHERE uid = studentId and role = 0;
    COMMIT;
END;

