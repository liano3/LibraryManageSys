create
    definer = root@localhost procedure deleteStudent(IN studentId int)
BEGIN
    START TRANSACTION;
    SET FOREIGN_KEY_CHECKS = 0;
    DELETE FROM student WHERE sid = studentId;
    DELETE FROM borrow WHERE sid = studentId;
    DELETE FROM reserve WHERE sid = studentId;
    DELETE FROM user WHERE uid = studentId;
    SET FOREIGN_KEY_CHECKS = 1;
    COMMIT;
END;

