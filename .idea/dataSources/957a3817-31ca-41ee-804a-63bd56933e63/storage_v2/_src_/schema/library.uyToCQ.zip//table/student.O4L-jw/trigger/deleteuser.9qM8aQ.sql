create definer = root@localhost trigger deleteUser
    after delete
    on student
    for each row
BEGIN
    DELETE FROM user WHERE uid = OLD.sid and role = 0;
END;

