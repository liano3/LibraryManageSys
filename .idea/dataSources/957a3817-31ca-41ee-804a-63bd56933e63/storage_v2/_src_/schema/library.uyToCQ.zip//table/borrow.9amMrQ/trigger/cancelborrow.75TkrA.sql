create definer = root@localhost trigger cancelBorrow
    after delete
    on borrow
    for each row
BEGIN
    UPDATE book SET status = 0 WHERE bid = OLD.bid;
END;

