create
    definer = root@localhost function activeStudent() returns int reads sql data
BEGIN
    DECLARE activeStudentId INT;
    SELECT sid INTO activeStudentId FROM borrow WHERE MONTH(borrow_date) = MONTH(CURDATE()) GROUP BY sid ORDER BY COUNT(*) DESC LIMIT 1;
    RETURN activeStudentId;
END;

