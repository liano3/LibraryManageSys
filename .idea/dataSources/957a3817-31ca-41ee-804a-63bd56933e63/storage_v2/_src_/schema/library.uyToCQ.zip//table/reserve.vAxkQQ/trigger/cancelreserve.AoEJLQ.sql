create definer = root@localhost trigger cancelReserve
    after delete
    on reserve
    for each row
BEGIN
    UPDATE book SET status = 0 WHERE bid = OLD.bid;
END;

