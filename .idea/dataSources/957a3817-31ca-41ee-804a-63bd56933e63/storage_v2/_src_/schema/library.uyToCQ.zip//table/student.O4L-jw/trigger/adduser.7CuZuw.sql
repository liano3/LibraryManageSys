create definer = root@localhost trigger addUser
    after insert
    on student
    for each row
BEGIN
    # 默认用户名为 0+sid，密码为 123456
    INSERT INTO user(uid, username, password, role) VALUES (NEW.sid, CONCAT('0', NEW.sid), '123456', 0);
END;

