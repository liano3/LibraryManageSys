create
    definer = root@localhost procedure killUser(IN studentId int)
label: BEGIN
    START TRANSACTION;
    -- 删除预约记录
    DELETE FROM reserve WHERE sid = studentId;
    -- 冻结用户
    UPDATE user SET status = 1 WHERE uid = studentId and role = 0;
    COMMIT;
END;

