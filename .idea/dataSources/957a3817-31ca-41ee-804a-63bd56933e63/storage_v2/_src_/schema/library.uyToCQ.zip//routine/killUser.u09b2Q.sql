create
    definer = root@localhost procedure killUser(IN studentId int)
label: BEGIN
    START TRANSACTION;
    -- 设置预约记录过期时间
    UPDATE reserve SET pass_date = CURDATE() WHERE sid = studentId AND take_date < CURDATE() AND pass_date IS NULL;
    -- 冻结用户
    UPDATE user SET status = 1 WHERE uid = studentId and role = 0;
    COMMIT;
END;

