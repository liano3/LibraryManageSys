create definer = root@localhost trigger passReserve
    after update
    on reserve
    for each row
BEGIN
    -- 判断是否过期
    if NEW.take_date < CURDATE() THEN
        UPDATE book SET status = 0 WHERE bid = NEW.bid;
    END IF;
END;

